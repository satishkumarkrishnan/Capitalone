package com.amazonaws.lab;


import java.io.File;
import java.util.List;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.CopyObjectRequest;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3ObjectSummary;

public class SListObjects {
	static String bucketName="awsdocforsample";
	public static void main(String[] args) {
		
		/*String key = "statement_sample1.PDF";*/
		String Destkey;
		String clientRegion = "ap-south-1";
		try{
		AmazonS3 s3Client = AmazonS3ClientBuilder.standard()
                .withRegion(clientRegion)
                .withCredentials(DefaultAWSCredentialsProviderChain.getInstance())
                .build();
                
		/*final AmazonS3 s3 = AmazonS3ClientBuilder.defaultClient();*/
		/*s3.putObject(new PutObjectRequest(bucketName, key, new File("https://s3.ap-south-1.amazonaws.com/awsdocforsample/statement_sample1.PDF/key.pdf")).withCannedAcl(CannedAccessControlList.PublicRead));
		//s3.getre
*/		ObjectListing ol=s3Client.listObjects(bucketName);
		List<S3ObjectSummary> objects=ol.getObjectSummaries();
		CopyObjectRequest copyObjRequest;
		for(S3ObjectSummary os: objects){
			/*System.out.println("*"  +os.getSize());*/
			System.out.println(" KEY_NAME "  +os.getKey());
			
			String actkey=os.getKey();
			/*System.out.println("BUCKET_NAME "  +os.getBucketName());*/
			Destkey = os.getKey()+"_old";
			System.out.println(" KEY_NAME "  + Destkey);
			copyObjRequest = new CopyObjectRequest(bucketName, os.getKey(), "awscopyobject", Destkey);
	        s3Client.copyObject(copyObjRequest);
			/*System.out.println("*"  +os.getOwner());
			System.out.println("*"  +os.getETag());*/
			
	        //String newKey = os.getKey();
			System.out.println(" KEY_NAME_reverse"  + os.getKey());
			copyObjRequest = new CopyObjectRequest("awscopyobject", Destkey, "awscopyobject", os.getKey());
	        s3Client.copyObject(copyObjRequest);
	       /* if(!actkey.equals(Destkey)){
	        	
	        }*/
	        s3Client.deleteObject(new DeleteObjectRequest("awscopyobject", Destkey));
	        System.out.println("successfully deleted");
				
		}
		
		
	}
		
	/*try {
        AmazonS3 s3Client = AmazonS3ClientBuilder.standard()
                .withCredentials(new ProfileCredentialsProvider())
                .withRegion(clientRegion)
                .build();

        // Copy the object into a new object in the same bucket.
        CopyObjectRequest copyObjRequest = new CopyObjectRequest(bucketName, sourceKey, bucketName, destinationKey);
        s3Client.copyObject(copyObjRequest);
    }*/
    catch(AmazonServiceException e) {
        // The call was transmitted successfully, but Amazon S3 couldn't process 
        // it, so it returned an error response.
        e.printStackTrace();
    }
    catch(SdkClientException e) {
        // Amazon S3 couldn't be contacted for a response, or the client  
        // couldn't parse the response from Amazon S3.
        e.printStackTrace();
    }

}
}

