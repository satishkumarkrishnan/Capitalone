package com.amazonaws.lab;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.AmazonS3Exception;
import com.amazonaws.services.s3.model.Bucket;

import java.io.IOException;
import java.nio.file.Paths;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.policy.Policy;
import com.amazonaws.auth.policy.Principal;
import com.amazonaws.auth.policy.Resource;
import com.amazonaws.auth.policy.Statement;
import com.amazonaws.auth.policy.actions.S3Actions;
import java.io.IOException;


import java.io.IOException;
import java.util.List;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.policy.Policy;
import com.amazonaws.auth.policy.Principal;
import com.amazonaws.auth.policy.Resource;
import com.amazonaws.auth.policy.Statement;
import com.amazonaws.auth.policy.actions.S3Actions;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;

public class SetBucketPolicy {

	private static String policy_text;
	static String clientRegion = "ap-south-1";
	private static Object file_text;

	public static void main(String[] args) throws IOException {
        String bucket_name = "awscreatebucket";
        AmazonS3 s3 = AmazonS3ClientBuilder.standard()
                .withRegion(clientRegion)
                .withCredentials(DefaultAWSCredentialsProviderChain.getInstance())
                .build();
        try {
            s3.setBucketPolicy(bucket_name, policy_text);
        } catch (AmazonServiceException e) {
            System.err.println(e.getErrorMessage());
            System.exit(1);
        }
        
        Policy bucket_policy = new Policy().withStatements(
        	    new Statement(Statement.Effect.Allow)
        	        .withPrincipals(Principal.AllUsers)
        	        .withActions(S3Actions.GetObject)
        	        .withResources(new Resource(
        	            "arn:aws:s3:::awsdocforsample" + bucket_name + "/*")));
        	
        	//Policy bucket_policy = null;
        	try {
        	    bucket_policy = Policy.fromJson(file_text.toString());
        	} catch (IllegalArgumentException e) {
        	    System.out.format("Invalid policy text in file: \"%s\"",
        	            policy_text);
        	    System.out.println(e.getMessage());
        	}

	}
	
}


