package com.amazonaws.lab;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.AmazonS3Exception;
import com.amazonaws.services.s3.model.Bucket;

import java.io.IOException;
import java.nio.file.Paths;

import com.amazonaws.AmazonServiceException;


import java.io.IOException;
import java.util.List;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.policy.Policy;
import com.amazonaws.auth.policy.Principal;
import com.amazonaws.auth.policy.Resource;
import com.amazonaws.auth.policy.Statement;
import com.amazonaws.auth.policy.actions.S3Actions;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;



public class create_bucket {
	static Bucket b = null;
	static String clientRegion = "ap-south-1";
	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws IOException {
        String bucket_name = "awscreatebucket";
        AmazonS3 s3 = AmazonS3ClientBuilder.standard()
                .withRegion(clientRegion)
                .withCredentials(DefaultAWSCredentialsProviderChain.getInstance())
                .build();
	
	if (s3.doesBucketExist(bucket_name)) {
	    System.out.format("Bucket %s already exists.\n", bucket_name);
	    
	}//if 
	else {
	    try {
	    	
	        b = s3.createBucket(bucket_name);
	    } catch (AmazonS3Exception e) {
	        System.err.println(e.getErrorMessage());
	    }//catch
	}//else

	}//main
	public static class SetBucketPolicy
	{
	    // Loads a JSON-formatted policy from a file, verifying it with the Policy
	    // class.
	    @SuppressWarnings("unused")
		private static String getBucketPolicyFromFile(String policy_file)
	    {
	        StringBuilder file_text = new StringBuilder();
	       
	        
	        try {
	            List<String> lines = Files.readAllLines(
	            Paths.get(policy_file), Charset.forName("UTF-8"));
	            for (String line : lines) {
	                file_text.append(line);
	            }
	              
	        } catch (IOException e) {
	            System.out.format("Problem reading file: \"%s\"", policy_file);
	            
	            System.out.println(e.getMessage());
	           
	        }//catch
	     
			return policy_file;
			
}
	}
}




	